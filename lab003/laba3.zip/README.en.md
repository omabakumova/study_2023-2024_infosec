# Course Catalog Template for Students

## Clone repository

git clone --recursive https://github.com/yamadharma/course-directory-student-template.git

